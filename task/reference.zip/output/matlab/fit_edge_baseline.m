function [beta,baseline,normalizedHit,normalizedSigma] = fit_edge_baseline(T)
good = T.quality_flag==0;
fitRows = good & T.baseline_anchor==1;
X = [double(T.segment_id==1),double(T.segment_id==2),double(T.segment_id==3), ...
    T.common_trend1,T.common_trend2,T.common_trend3];
Aw = X(fitRows,:)./T.hit_sigma(fitRows);
bw = T.hit_index(fitRows)./T.hit_sigma(fitRows);
beta = Aw\bw;
baseline = X*beta;
assert(all(isfinite(beta)) && all(baseline>0));
normalizedHit = T.hit_index./baseline;
normalizedSigma = T.hit_sigma./baseline;
end
