function run_edge_degradation_audit(inputRoot,outputRoot)
validate_edge_inputs(inputRoot);
C = jsondecode(fileread(fullfile(inputRoot,"degradation_contract.json")));
T = readtable(fullfile(inputRoot,"edge_hit_rate.csv"));

outputParent=fileparts(outputRoot);
if ~isfolder(outputParent), mkdir(outputParent); end
staging=[tempname(outputParent) "_edge_results"];
mkdir(staging);
cleanup=onCleanup(@()cleanup_staging(staging));

[beta,baseline,y,sigma] = fit_edge_baseline(T);
good = T.quality_flag==0;
w=1./sigma.^2;
[best,intervalScan] = search_periodic_degradation(T.time_days,y,w,good,C);

coef = table(["segment_1";"segment_2";"segment_3"; ...
    "common_trend1";"common_trend2";"common_trend3"],beta, ...
    'VariableNames',["coefficient","value"]);
writetable(coef,fullfile(staging,"baseline_coefficients.csv"));
N = table(T.sample_id,T.time_days,T.segment_id,y,sigma,good, ...
    'VariableNames',["sample_id","time_days","segment_id", ...
    "normalized_hit_index","normalized_sigma","used_in_detection"]);
writetable(N,fullfile(staging,"normalized_edge_signal.csv"));
writetable(intervalScan,fullfile(staging,"interval_scan.csv"));
solution = struct2table(rmfield(best,{"valid","drop","inside"}));
writetable(solution,fullfile(staging,"degradation_solution.csv"));

windowNumbers = unique(round((T.time_days(best.inside)-best.epoch_days)/best.interval_days));
windowRows = zeros(numel(windowNumbers),4);
outside = good & ~best.inside;
meanOut = sum(w(outside).*y(outside))/sum(w(outside));
for i=1:numel(windowNumbers)
    n=windowNumbers(i);
    mask=best.inside & round((T.time_days-best.epoch_days)/best.interval_days)==n;
    localDrop=(meanOut-sum(w(mask).*y(mask))/sum(w(mask)))*1e4;
    windowRows(i,:)=[n,best.epoch_days+n*best.interval_days,nnz(mask),localDrop];
end
E=array2table(windowRows,'VariableNames', ...
    ["window_number","center_days","observed_points","local_drop_bps"]);
writetable(E,fullfile(staging,"degradation_windows.csv"));

clean=y;
clean(best.inside)=clean(best.inside)+best.drop;
R=table();
for interval0=C.fault_injection.intervals_days(:)'
 for drop=C.fault_injection.drops(:)'
  for phase0=C.fault_injection.phase_indices(:)'
   epoch0=phase0/48*interval0;
   injectMask=good & abs(mod(T.time_days-epoch0+interval0/2,interval0)-interval0/2) ...
       <=C.fault_injection.window_days/2;
   injected=clean;
   injected(injectMask)=injected(injectMask)-drop;
   local=[];
   for mult=C.fault_injection.local_interval_multipliers(:)'
    interval=interval0*mult;
    for off=C.fault_injection.local_phase_offsets(:)'
     phaseIndex=mod(phase0+off,48);
     for window=C.fault_injection.local_windows_days(:)'
      z=score_drop_box(T.time_days,injected,w,good,interval,window,phaseIndex, ...
          C.detection.minimum_affected_points,C.detection.minimum_observed_windows);
      if z.valid && candidate_better(z,local), local=z; end
     end
    end
   end
   assert(~isempty(local),"Fault injection produced no local candidate");
   relInterval=abs(local.interval_days-interval0)/interval0;
   phaseError=min(abs(local.phase_index-phase0),48-abs(local.phase_index-phase0));
   relDrop=abs(local.drop-drop)/drop;
   D=C.fault_injection.detection;
   detected=relInterval<=D.maximum_relative_interval_error && ...
       phaseError<=D.maximum_circular_phase_bin_error && ...
       local.score>=D.minimum_score && ...
       relDrop<=D.maximum_relative_drop_error;
   injectionId=sprintf("I%.1f_B%04d_F%02d",interval0,round(drop*1e4),phase0);
   row=table(string(injectionId),interval0,drop*1e4,phase0, ...
       local.interval_days,local.drop_bps,local.phase_index,local.score, ...
       relInterval,phaseError,relDrop,detected, ...
       'VariableNames',["injection_id","injected_interval_days","injected_drop_bps", ...
       "injected_phase_index","detected_interval_days","detected_drop_bps", ...
       "detected_phase_index","detected_score","relative_interval_error", ...
       "phase_bin_error","relative_drop_error","detected"]);
   R=[R;row]; %#ok<AGROW>
  end
 end
end
writetable(R,fullfile(staging,"fault_injection_detection.csv"));

drops=C.fault_injection.drops(:)*1e4;
count=zeros(numel(drops),1);
total=zeros(numel(drops),1);
for i=1:numel(drops)
 mask=abs(R.injected_drop_bps-drops(i))<1e-6;
 total(i)=nnz(mask);
 count(i)=nnz(R.detected(mask));
end
detectionRate=count./total;
Q=table(drops,total,count,detectionRate, ...
    'VariableNames',["injected_drop_bps","injections","detected_count","detection_rate"]);
writetable(Q,fullfile(staging,"detection_sensitivity.csv"));
eligibleDrops=drops(detectionRate>=C.fault_injection.detection_rate_threshold);
if isempty(eligibleDrops), detectionLimit=NaN; else, detectionLimit=min(eligibleDrops); end

if isfolder(outputRoot), rmdir(outputRoot,"s"); end
movefile(staging,outputRoot);
clear cleanup;
end

function validate_edge_inputs(inputRoot)
C=jsondecode(fileread(fullfile(inputRoot,"degradation_contract.json")));
assert(C.detection.interval_stop_days>C.detection.interval_start_days);
assert(C.detection.interval_step_days>0 && C.detection.phase_bins_per_interval>0);
assert(~isempty(C.detection.window_days));
assert(~isempty(C.fault_injection.intervals_days));
assert(~isempty(C.fault_injection.drops));
assert(~isempty(C.fault_injection.phase_indices));

T=readtable(fullfile(inputRoot,"edge_hit_rate.csv"));
expectedColumns=["sample_id","time_days","hit_index","hit_sigma","quality_flag", ...
    "segment_id","common_trend1","common_trend2","common_trend3","baseline_anchor"];
assert(isequal(string(T.Properties.VariableNames),expectedColumns),"CSV header mismatch");
assert(height(T)>0 && numel(unique(T.sample_id))==height(T),"sample_id boundary mismatch");
assert(all(ismember(T.quality_flag,[0 1 2])),"quality_flag domain mismatch");
assert(all(ismember(T.segment_id,[1 2 3])),"segment_id domain mismatch");
assert(all(T.hit_sigma>0) && all(isfinite(T.hit_index)),"measurement domain mismatch");
assert(all(ismember(T.baseline_anchor,[0 1])),"baseline_anchor domain mismatch");
end

function yes = candidate_better(x,b)
if isempty(b), yes=true; return; end
if x.score>b.score+1e-12, yes=true; return; end
if abs(x.score-b.score)<=1e-12
    left=[x.interval_days,x.window_days,x.phase_index];
    right=[b.interval_days,b.window_days,b.phase_index];
    k=find(left~=right,1);
    yes=~isempty(k) && left(k)<right(k);
else
    yes=false;
end
end

function cleanup_staging(staging)
if isfolder(staging), rmdir(staging,"s"); end
end
