function candidate = score_drop_box(time,y,w,good,interval,window,phaseIndex,minimumPoints,minimumWindows)
epoch = phaseIndex/48*interval;
delta = mod(time-epoch+interval/2,interval)-interval/2;
inside = good & abs(delta)<=window/2;
outside = good & ~inside;
windowNumber = unique(round((time(inside)-epoch)/interval));
candidate = struct("valid",false);
if nnz(inside)<minimumPoints || numel(windowNumber)<minimumWindows, return; end
meanIn = sum(w(inside).*y(inside))/sum(w(inside));
meanOut = sum(w(outside).*y(outside))/sum(w(outside));
drop = meanOut-meanIn;
if drop<=0, return; end
stderr = sqrt(1/sum(w(inside))+1/sum(w(outside)));
candidate = struct("valid",true,"interval_days",interval,"window_days",window, ...
    "phase_index",phaseIndex,"epoch_days",epoch,"drop",drop,"drop_bps",drop*1e4, ...
    "score",drop/stderr,"affected_points",nnz(inside), ...
    "observed_windows",numel(windowNumber),"inside",inside);
end
