function [best,intervalScan] = search_periodic_degradation(time,y,w,good,C)
intervals = C.detection.interval_start_days:C.detection.interval_step_days:C.detection.interval_stop_days;
windows = C.detection.window_days(:)';
intervalScan = table(); best = [];
for interval = intervals
    local = [];
    for window = windows
        for phaseIndex = 0:C.detection.phase_bins_per_interval-1
            z = score_drop_box(time,y,w,good,interval,window,phaseIndex, ...
                C.detection.minimum_affected_points,C.detection.minimum_observed_windows);
            if z.valid && better(z,local), local=z; end
        end
    end
    assert(~isempty(local),"No valid degradation candidate for one interval");
    row = struct2table(rmfield(local,{"valid","drop","inside"}));
    intervalScan = [intervalScan;row]; %#ok<AGROW>
    if better(local,best), best=local; end
end
end

function yes = better(x,b)
if isempty(b), yes=true; return; end
if x.score>b.score+1e-12, yes=true; return; end
if abs(x.score-b.score)<=1e-12
    yes = lexicographicLess([x.interval_days,x.window_days,x.phase_index], ...
                            [b.interval_days,b.window_days,b.phase_index]);
else
    yes=false;
end
end

function yes = lexicographicLess(a,b)
k=find(a~=b,1); yes=~isempty(k) && a(k)<b(k);
end
