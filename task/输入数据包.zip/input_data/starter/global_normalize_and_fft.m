function [frequency,power] = global_normalize_and_fft(hitIndex)
% 现用粗略方法未纳入质量位、分段基线、异方差和矩形退化窗口。
y = hitIndex./median(hitIndex)-1;
power = abs(fft(y)).^2;
frequency = (0:numel(y)-1)'/numel(y);
end
